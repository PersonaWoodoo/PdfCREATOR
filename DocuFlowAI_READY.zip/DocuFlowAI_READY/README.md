# DocuFlow AI — Telegram Mini App и бот

## Что есть
- Telegram Mini App `index.html` и FastAPI `server.py` в одном приложении.
- Авторизация через проверку подписи Telegram `initData` на сервере.
- Генерация текста Gemini через OpenAI-совместимый API; PDF, DOCX, PPTX, TXT, MD, JSON.
- Отправка созданных файлов в Telegram, загрузка изображений.
- Оплата Telegram Stars (XTR), обработка pre_checkout_query и successful_payment, подписки.
- Администратор Telegram ID 8959461245; статистика через `/api/admin/summary` из Mini App с авторизацией.

## Запуск
1. Нужен сервер с Python 3.10+ и публичным **HTTPS-доменом**. Только статический HTML-хостинг недостаточен.
2. `pip install -r requirements.txt`
3. Скопируйте `.env.example` в `.env` и заполните **новые** BOT_TOKEN, AI_API_KEY, BOT_USERNAME, PUBLIC_URL, WEBHOOK_SECRET. Никогда не вставляйте секреты в index.html.
4. `uvicorn server:app --host 0.0.0.0 --port 8000` (в продакшене запускайте через процесс-менеджер и HTTPS reverse proxy).
5. `python setup_webhook.py` после настройки HTTPS.
6. В BotFather задайте Menu Button URL = ваш PUBLIC_URL, затем откройте бота, нажмите `/start` и запустите Mini App.

## Важно
- Счета в Stars создаются через Telegram; подписка активируется только после Telegram successful_payment.
- Бот не может отправлять документы пользователю, пока тот не открыл чат с ботом и не нажал Start.
- Без настоящих ключей, хостинга и Telegram-тестирования нельзя гарантировать работоспособность внешних интеграций.
- Бесплатный Gemini API ограничен по доступности и квотам; при превышении лимитов генерация завершится ошибкой.
- Задачи генерации работают в памяти процесса, поэтому для масштабирования нужны очередь заданий и отдельный worker.
- Прежде чем запускать для реальных клиентов, проверьте оплату, возвраты, обработку ошибок, безопасность и резервное копирование базы.
